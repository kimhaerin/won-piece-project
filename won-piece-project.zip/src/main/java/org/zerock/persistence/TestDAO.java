package org.zerock.persistence;

import org.zerock.domain.TestVO;

public interface TestDAO extends GenericDAO<TestVO, Integer> {
	
}
