package org.zerock.persistence;

import org.zerock.domain.SmemVO;

public interface SmemDAO extends GenericDAO<SmemVO, String> {
	
}
