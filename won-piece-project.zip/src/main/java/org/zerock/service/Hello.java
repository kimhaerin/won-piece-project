package org.zerock.service;

public interface Hello {
	
	public String sayHello();

}
